# membakedbean
 
## HOW TO USE

Go to membean, and click "All Words"
![Pointing at all words](https://github.com/Cheespeasa1234/membaked/blob/609b6ba5a8a65c004c431e5d88c39d12901880c5/img_for_readme/mbb1.jpg?raw=true)

Copy all the content
![Highlighting all the words](https://github.com/Cheespeasa1234/membaked/blob/e14db527b1e28857248b3184a6554bfef046e19f/img_for_readme/mbb2.png?raw=true)

Paste it into words.txt
![Pasted into words.txt](https://github.com/Cheespeasa1234/membaked/blob/695fa847e45597f3cd8d8f25b5ba0662ea3dbfc9/img_for_readme/mbb3.png?raw=true)

Repeat for Good Progress, Almost Ready, and Ready lists, but NOT "Quizzable"

Run Membaked in the terminal from the directory of this project
![python3 membaked.py](https://github.com/Cheespeasa1234/membaked/blob/695fa847e45597f3cd8d8f25b5ba0662ea3dbfc9/img_for_readme/mbb6.jpg?raw=true)

Enter a membean training session

## PROFIT!